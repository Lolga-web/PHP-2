-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 15 2021 г., 05:55
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `php_2_lesson_7`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `img`, `description`, `price`) VALUES
(1, 'Товар №1', '1.jpg', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores quo perferendis nisi facilis tempora. Vero sunt voluptatum, minima cupiditate nam molestiae asperiores eius quidem hic veritatis sapiente dolor commodi sequi. Perferendis obcaecati, nesciunt odit magni reiciendis ullam earum ipsa, amet eaque repudiandae, repellat numquam quod. Tempora ratione accusantium velit est error, corrupti sint nobis! Quaerat hic ullam dolorum magni et sit? Fugiat ullam adipisci quod laudantium rem in tempore quam ducimus ipsam temporibus ad quisquam nesciunt ut porro modi atque, vero hic culpa sint soluta animi! Dolor voluptatem omnis magnam dolore sapiente vero, qui facere, sint dicta eos aliquid quaerat, rem earum rerum natus minus reiciendis tempore pariatur illo accusantium perspiciatis accusamus. Quos magni neque labore totam, ratione quaerat, sint nulla vel corrupti, ab iure laudantium autem recusandae deleniti voluptatibus quae porro maiores nisi cupiditate soluta tempore natus voluptate assumenda? Delectus libero, adipisci laboriosam voluptatem nemo et iste rerum quidem maxime, voluptate reiciendis quasi tempora consequuntur sequi expedita amet! Facilis corporis iste alias, ipsum eligendi distinctio sapiente possimus quas. ', 20000),
(2, 'Товар №2', '1.jpg', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores quo perferendis nisi facilis tempora. Vero sunt voluptatum, minima cupiditate nam molestiae asperiores eius quidem hic veritatis sapiente dolor commodi sequi. Perferendis obcaecati, nesciunt odit magni reiciendis ullam earum ipsa, amet eaque repudiandae, repellat numquam quod. Tempora ratione accusantium velit est error, corrupti sint nobis! Quaerat hic ullam dolorum magni et sit? Fugiat ullam adipisci quod laudantium rem in tempore quam ducimus ipsam temporibus ad quisquam nesciunt ut porro modi atque, vero hic culpa sint soluta animi! Dolor voluptatem omnis magnam dolore sapiente vero, qui facere, sint dicta eos aliquid quaerat, rem earum rerum natus minus reiciendis tempore pariatur illo accusantium perspiciatis accusamus. Quos magni neque labore totam, ratione quaerat, sint nulla vel corrupti, ab iure laudantium autem recusandae deleniti voluptatibus quae porro maiores nisi cupiditate soluta tempore natus voluptate assumenda? Delectus libero, adipisci laboriosam voluptatem nemo et iste rerum quidem maxime, voluptate reiciendis quasi tempora consequuntur sequi expedita amet! Facilis corporis iste alias, ipsum eligendi distinctio sapiente possimus quas. ', 10000),
(3, 'Товар №3', '1.jpg', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores quo perferendis nisi facilis tempora. Vero sunt voluptatum, minima cupiditate nam molestiae asperiores eius quidem hic veritatis sapiente dolor commodi sequi. Perferendis obcaecati, nesciunt odit magni reiciendis ullam earum ipsa, amet eaque repudiandae, repellat numquam quod. Tempora ratione accusantium velit est error, corrupti sint nobis! Quaerat hic ullam dolorum magni et sit? Fugiat ullam adipisci quod laudantium rem in tempore quam ducimus ipsam temporibus ad quisquam nesciunt ut porro modi atque, vero hic culpa sint soluta animi! Dolor voluptatem omnis magnam dolore sapiente vero, qui facere, sint dicta eos aliquid quaerat, rem earum rerum natus minus reiciendis tempore pariatur illo accusantium perspiciatis accusamus. Quos magni neque labore totam, ratione quaerat, sint nulla vel corrupti, ab iure laudantium autem recusandae deleniti voluptatibus quae porro maiores nisi cupiditate soluta tempore natus voluptate assumenda? Delectus libero, adipisci laboriosam voluptatem nemo et iste rerum quidem maxime, voluptate reiciendis quasi tempora consequuntur sequi expedita amet! Facilis corporis iste alias, ipsum eligendi distinctio sapiente possimus quas. ', 30000),
(4, 'Товар №4', '1.jpg', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores quo perferendis nisi facilis tempora. Vero sunt voluptatum, minima cupiditate nam molestiae asperiores eius quidem hic veritatis sapiente dolor commodi sequi. Perferendis obcaecati, nesciunt odit magni reiciendis ullam earum ipsa, amet eaque repudiandae, repellat numquam quod. Tempora ratione accusantium velit est error, corrupti sint nobis! Quaerat hic ullam dolorum magni et sit? Fugiat ullam adipisci quod laudantium rem in tempore quam ducimus ipsam temporibus ad quisquam nesciunt ut porro modi atque, vero hic culpa sint soluta animi! Dolor voluptatem omnis magnam dolore sapiente vero, qui facere, sint dicta eos aliquid quaerat, rem earum rerum natus minus reiciendis tempore pariatur illo accusantium perspiciatis accusamus. Quos magni neque labore totam, ratione quaerat, sint nulla vel corrupti, ab iure laudantium autem recusandae deleniti voluptatibus quae porro maiores nisi cupiditate soluta tempore natus voluptate assumenda? Delectus libero, adipisci laboriosam voluptatem nemo et iste rerum quidem maxime, voluptate reiciendis quasi tempora consequuntur sequi expedita amet! Facilis corporis iste alias, ipsum eligendi distinctio sapiente possimus quas. ', 15000);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id_order` int NOT NULL,
  `id_user` int NOT NULL,
  `date_order` text NOT NULL,
  `status_order` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id_order`, `id_user`, `date_order`, `status_order`) VALUES
(1, 13, '14/01/2021', 'Активен'),
(2, 13, '14/01/2021', 'Активен'),
(3, 13, '14/01/2021', 'Активен'),
(4, 27, '14/01/2021', 'Активен');

-- --------------------------------------------------------

--
-- Структура таблицы `order_goods`
--

CREATE TABLE `order_goods` (
  `id` int NOT NULL,
  `id_order` int NOT NULL,
  `id_good` int NOT NULL,
  `good_count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_goods`
--

INSERT INTO `order_goods` (`id`, `id_order`, `id_good`, `good_count`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1),
(3, 2, 3, 2),
(4, 2, 2, 1),
(5, 3, 2, 2),
(6, 3, 3, 1),
(7, 4, 32, 3),
(8, 4, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(55) NOT NULL,
  `login` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `password`) VALUES
(13, 'Андрей', 'user', 'ee32c060ac0caa70b04e25091bbc11eeee11cbb19052e40b07aac0ca060c23ee'),
(27, 'Елена', 'user2', '0273a989784c1a55bec79106b36d85e77e58d63b60197ceb55a1c487989a3720'),
(28, 'Ольга', 'admin', '3cf108a4e0a498347a5a75a792f2321221232f297a57a5a743894a0e4a801fc3');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`);

--
-- Индексы таблицы `order_goods`
--
ALTER TABLE `order_goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `order_goods`
--
ALTER TABLE `order_goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
